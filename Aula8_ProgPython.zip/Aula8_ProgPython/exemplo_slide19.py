def soma(valor1, valor2, imprime = False):
    resultado = valor1 + valor2
    if imprime:
        print(f"Soma: {resultado}")
    return resultado # Se não utilizarmos o return, a função retorna None por padrão, 
                     #pois resultado é uma variável local.
                     
total = soma(imprime= True, valor2 = 10, valor1 =84)
total = soma(10, 20)
print(f"Total: {total}")