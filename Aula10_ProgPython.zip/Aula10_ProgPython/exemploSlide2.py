cidade = 'São Carlos'
endereco = 'Rua Cândido Padim, 25 - Vila Prado'
completo = cidade + endereco

print(cidade.startswith('São'))

print(cidade.endswith('los'))

print('Rua' in completo)

print('Avenida' not in completo)