from .impostos import somaImposto

__all__ = ["somaImposto"]