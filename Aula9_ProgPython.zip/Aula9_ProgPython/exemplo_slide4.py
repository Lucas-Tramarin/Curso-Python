soma = lambda lista: sum(lista)

numeros = [1, 5, 10, 50]
total = soma(numeros)
print(total)

numeros = [80, 74, 25]
total = soma(numeros)
print(total)