from functools import reduce

lista = [1, 2, 3, 4, 5, 6]
produto = reduce(lambda x,y: x * y, lista) 
#retorna o produto de todos os elemento de lista
print("lista = ", lista,"\n\nproduto = ", produto)