from meu_pacote import somaImposto

# Entrada dos dados
taxa = float(input("Informe a taxa de imposto (%): "))
custo = float(input("Informe o custo do item: "))

# Chamada da função
resultado = somaImposto(taxa, custo)

# Exibe o resultado
print(f"Valor final com imposto: {resultado:.2f}")
