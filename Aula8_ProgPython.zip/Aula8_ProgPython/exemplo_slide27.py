def validar_tamanho(texto, maximo):
    if len(texto) > maximo:
        print(f"O texto deve conter no máximo {maximo} caracteres!")
    else:
        return True
    
#Chamando a função em loop até o usuário informar um valor válido:
while True:
    texto = input(f"Informe um texto de no máximo 5 caracteres: ")
    if validar_tamanho(texto, 5):
        break