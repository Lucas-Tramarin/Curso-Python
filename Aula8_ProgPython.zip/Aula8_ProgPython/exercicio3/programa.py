# programa.py

from meu_pacote_pagamentos import valorPagamento

print("=== Sistema de Pagamento de Prestações ===")
total_prestacoes = 0
soma_total = 0.0

while True:
        # solicita o valor da prestação
        entrada_valor = input("Informe o valor da prestação (0 para encerrar): ").strip()
        # aceita vírgula como decimal
        entrada_valor = entrada_valor.replace(",", ".")
        try:
            valor_prest = float(entrada_valor)
        except ValueError:
            print("Valor inválido. Tente novamente.")
            continue

        if valor_prest == 0:
            # encerra o loop e mostra relatório
            break

        # solicita dias de atraso (inteiro, pode ser 0 ou positivo)
        entrada_dias = input("Informe o número de dias em atraso (0 se não houver): ").strip()
        try:
            dias_atraso = int(entrada_dias)
        except ValueError:
            print("Dias inválidos. Use um número inteiro. A entrada será reiniciada.")
            continue

        # calcula usando função importada
        try:
            valor_a_pagar = valorPagamento(valor_prest, dias_atraso)
        except ValueError as e:
            print(f"Erro no cálculo: {e}")
            continue

        # exibe o valor a pagar
        print(f"Valor a pagar: R$ {valor_a_pagar:.2f}")

        # acumula para o relatório
        total_prestacoes += 1
        soma_total += valor_a_pagar

    # relatório final
print("\n=== Relatório do dia ===")
print(f"Quantidade de prestações pagas: {total_prestacoes}")
print(f"Valor total recebido: R$ {soma_total:.2f}")
print("Encerrando o programa. Obrigado.")
