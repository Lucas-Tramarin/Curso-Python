'''Faça um programa que receba o usuário escolha qual unidade de medida
 esta inserindo a temperatura e converta para a temperatura requerida'''
#As unidades de medida são Celsius, Fahrenheit e Kelvin

def celsius_para_fahrenheit(celsius):
    return (celsius * 9/5) + 32
def celsius_para_kelvin(celsius):
    return celsius + 273.15
def fahrenheit_para_celsius(fahrenheit):
    return (fahrenheit - 32) * 5/9
def fahrenheit_para_kelvin(fahrenheit):
    return (fahrenheit - 32) * 5/9 + 273.15
def kelvin_para_celsius(kelvin):
    return kelvin - 273.15
def kelvin_para_fahrenheit(kelvin):
    return (kelvin - 273.15) * 9/5 + 32

print("Escolha a unidade de medida da temperatura que deseja inserir:")
print("1 - Celsius")        
print("2 - Fahrenheit")
print("3 - Kelvin")

opcao_entrada = int(input("Digite o número correspondente à unidade de medida: "))      
temperatura_entrada = float(input("Digite a temperatura que deseja converter: "))
print("Escolha a unidade de medida para a qual deseja converter:")
print("1 - Celsius")
print("2 - Fahrenheit")
print("3 - Kelvin")
opcao_saida = int(input("Digite o número correspondente à unidade de medida: "))

if opcao_entrada == 1:  # Celsius
    if opcao_saida == 1:
        temperatura_saida = temperatura_entrada
    elif opcao_saida == 2:
        temperatura_saida = celsius_para_fahrenheit(temperatura_entrada)
    elif opcao_saida == 3:
        temperatura_saida = celsius_para_kelvin(temperatura_entrada)
elif opcao_entrada == 2:  # Fahrenheit
    if opcao_saida == 1:
        temperatura_saida = fahrenheit_para_celsius(temperatura_entrada)
    elif opcao_saida == 2:
        temperatura_saida = temperatura_entrada
    elif opcao_saida == 3:
        temperatura_saida = fahrenheit_para_kelvin(temperatura_entrada)
elif opcao_entrada == 3:  # Kelvin
    if opcao_saida == 1:
        temperatura_saida = kelvin_para_celsius(temperatura_entrada)
    elif opcao_saida == 2:
        temperatura_saida = kelvin_para_fahrenheit(temperatura_entrada)
    elif opcao_saida == 3:
        temperatura_saida = temperatura_entrada

print(f"A temperatura convertida é: {temperatura_saida}")

#fim do programa