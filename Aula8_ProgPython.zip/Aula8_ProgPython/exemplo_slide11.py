def fatorial(numero):
    if type(numero) is not int:
        return '\nO número deve ser um inteiro!'
    if numero <= 0:
        return 1
    else:
        return numero * fatorial(numero-1)
    
print(fatorial(5))
