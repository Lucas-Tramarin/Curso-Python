import operacoes

lista = []

while True:
    numero = int(input("Informe um número int ou 0 para sair: "))
    if numero == 0:
        break
    lista.append(numero)


soma = operacoes.soma(*lista)
media = operacoes.media(*lista)
print(f"Soma: {soma}")
print(f"Média: {media}")
