'''Faça um programa que solicite dez números ao usuário, depois disso, 
exiba todos números pares e só então exiba todos os números ímpares. 
Utilize a função filter para fazer isso.
'''
numeros = []
for i in range(10):
    num = int(input(f"Digite o {i+1}º número: "))
    numeros.append(num)
pares = list(filter(lambda x: x % 2 == 0, numeros))
impares = list(filter(lambda x: x % 2 != 0, numeros))

print("Números pares:", pares)
print("Números ímpares:", impares)

#fim do programa
