def soma(imprime, *valores): #aqui estamos usando o *args para receber múltiplos valores 
                             #que seráo usados como lista dentro da função
    total = 0
    for valor in valores:
        total += valor
    if imprime:
        print(f"Soma: {total}")
    return total #retornamos a variável total para que possa ser utilizada posteriormente
                 #fora da função

# Exemplo de uso da função soma
lista = [10, 20, 30, 40, 50]
soma(True, *lista) #usando o * para desempacotar a lista
soma(True, 10, 20, 30, 78)
soma(False, 10, 50)