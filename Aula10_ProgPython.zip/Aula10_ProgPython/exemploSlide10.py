a = '    Olá mundo    '
print(f'*{a}*')

b = a.strip()
print(f'*{b}*')

c = a.lstrip()
print(f'*{c}*')

d = a.rstrip()
print(f'*{d}*')