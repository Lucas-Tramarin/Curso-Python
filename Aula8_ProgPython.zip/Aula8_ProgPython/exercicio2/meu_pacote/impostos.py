def somaImposto(taxaImposto, custo):
    """
    Aplica o imposto ao valor de custo.

    taxaImposto: porcentagem de imposto (ex: 10 para 10%)
    custo: preço do item antes do imposto
    """
    taxa_decimal = taxaImposto / 100
    novo_custo = custo + (custo * taxa_decimal)
    return novo_custo
