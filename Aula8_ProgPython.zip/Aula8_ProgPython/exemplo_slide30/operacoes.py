def media(*lista_numeros):
    total = 0
    for numero in lista_numeros:
        total += numero
    resultado = total / len(lista_numeros)
    return resultado

def soma(*lista_numeros):
    total = 0
    for numero in lista_numeros:
        total += numero
    return total
