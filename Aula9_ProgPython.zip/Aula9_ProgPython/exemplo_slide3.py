
b = lambda x: x ** 2
print(b(4))

c = lambda x, y: x + y
print(c(2, 3))