'''Para substituir trechos de uma string podemos usar o método replace. Este método recebe por parâmetro a string que será substituída, a nova string, e por fim um número que limitará a quantidade de substituições.
Se o primeiro parâmetro do replace for vazio, será inserido o caractere informado antes de cada caractere da string e se o segundo parâmetro for vazio, o trecho será apagado'''

# Exemplo 1: Substituir uma substring por outra
texto = 'A força eletromotriz induzida em qualquer circuito fechado'
resultado1 = texto.replace('força', 'Bicicleta')
print("Exemplo 1 - Substituir substring:")
print(f"Original: {texto}")
print(f"Resultado: {resultado1}\n")

# Exemplo 2: Limitar o número de substituições
texto2 = 'banana banana banana'
resultado2 = texto2.replace('banana', 'maçã', 2)
print("Exemplo 2 - Limitar substituições a 2 ocorrências:")
print(f"Original: {texto2}")
print(f"Resultado: {resultado2}\n")

# Exemplo 3: Inserir caractere antes de cada caractere (primeiro parâmetro vazio)
texto3 = 'ABC'
resultado3 = texto3.replace('', '#')
print("Exemplo 3 - Inserir caractere antes de cada caractere:")
print(f"Original: {texto3}")
print(f"Resultado: {resultado3}\n")

# Exemplo 4: Apagar um trecho (segundo parâmetro vazio)
texto4 = 'Olá, mundo!'
resultado4 = texto4.replace(',', '')
print("Exemplo 4 - Apagar um trecho:")
print(f"Original: {texto4}")
print(f"Resultado: {resultado4}")