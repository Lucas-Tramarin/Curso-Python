'''Desenvolva um jogo da forca. O programa terá uma lista de palavras lidas de um
 arquivo texto e escolherá uma aleatoriamente.
 O jogador poderá errar 6 vezes antes de ser enforcado.
'''
import random
def carregar_palavras(nome_arquivo):
    with open(nome_arquivo, 'r', encoding='utf-8') as arquivo:
        palavras = [linha.strip() for linha in arquivo.readlines()]
    return palavras

def escolher_palavra(palavras):
    return random.choice(palavras).upper()

def jogar_forca():
    palavras = carregar_palavras('palavras.txt')
    palavra_secreta = escolher_palavra(palavras)
    letras_descobertas = ['_'] * len(palavra_secreta)
    tentativas = 6
    letras_erradas = []
    print("Bem-vindo ao jogo da forca!")
    while tentativas > 0 and '_' in letras_descobertas:
        print("\nPalavra: " + ' '.join(letras_descobertas))
        print(f"Tentativas restantes: {tentativas}")
        print(f"Letras erradas: {', '.join(letras_erradas)}")
        palpite = input("Digite uma letra: ").upper()
        if len(palpite) != 1 or not palpite.isalpha():
            print("Por favor, digite apenas uma letra.")
            continue
        if palpite in letras_descobertas or palpite in letras_erradas:
            print("Você já tentou essa letra. Tente outra.")
            continue
        if palpite in palavra_secreta:
            for idx, letra in enumerate(palavra_secreta):
                if letra == palpite:
                    letras_descobertas[idx] = palpite
            print("Boa! Você acertou uma letra.")
        else:
            tentativas -= 1
            letras_erradas.append(palpite)
            print("Letra incorreta.")
    if '_' not in letras_descobertas:
        print(f"Parabéns! Você ganhou! A palavra era: {palavra_secreta}")
    else:
        print(f"Você foi enforcado! A palavra era: {palavra_secreta}")
if __name__ == "__main__":
    jogar_forca()

