'''Faça um programa que solicite o nome do usuário e a idade do usuário, 
depois disso exiba a mensagem: “{nome} possui {idade} anos.”. 
Esta mensagem deve ser escrita em uma função lambda.'''

nome = input("Digite seu nome: ")
idade = input("Digite sua idade: ")
mensagem = lambda nome, idade: f"{nome} possui {idade} anos."

print(mensagem(nome, idade))

#fim do programa

