def soma(num1, num2):
    return num1 + num2

def multiplicacao(num1, num2):
    return num1 * num2

def calcular(funcao, num1, num2):
    return funcao(num1, num2)

total_soma = calcular(soma, 10, 20)
total_multiplicacao = calcular(multiplicacao, 10, 20)

print(f"Total Soma: {total_soma}")
print(f"Total Multiplicação: {total_multiplicacao}")