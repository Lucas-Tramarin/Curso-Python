'''Dado uma string com uma frase informada pelo usuário (incluindo espaços em branco), 
conte:
quantos espaços em branco existem na frase.
quantas vezes aparecem as vogais a, e, i, o, u'''

frase = input("Digite uma frase: ")
espacos = frase.count(' ')
vogal_a = frase.lower().count('a')
vogal_e = frase.lower().count('e')
vogal_i = frase.lower().count('i')
vogal_o = frase.lower().count('o')
vogal_u = frase.lower().count('u')
print(f"A frase digitada possui {espacos} espaços em branco.")
print(f"A vogal 'a' aparece {vogal_a} vezes.")
print(f"A vogal 'e' aparece {vogal_e} vezes.")
print(f"A vogal 'i' aparece {vogal_i} vezes.")
print(f"A vogal 'o' aparece {vogal_o} vezes.")
print(f"A vogal 'u' aparece {vogal_u} vezes.")

#Outra forma de fazer usando um loop
frase = input("Digite uma frase: ")
espacos = 0
vogais = {'a':0, 'e':0, 'i':0, 'o':0, 'u':0}
for char in frase.lower():      
    if char == ' ':
        espacos += 1
    elif char in vogais:
        vogais[char] += 1
print(f"A frase digitada possui {espacos} espaços em branco.")
for vogal, quantidade in vogais.items():
    print(f"A vogal '{vogal}' aparece {quantidade} vezes.")
