texto = 'Python é uma linguagem de programação. Python é simples./' \
' Python é organizado. Python é uma excelente linguagem.'

print(texto.count('é'))

print(texto.find('Python',25,50))

print(texto.rfind('lingua'))

print(texto.index('é'))

print(texto.rindex('é'))