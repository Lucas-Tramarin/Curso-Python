from meu_pacote2.operacoes import soma
from meu_pacote import *

print(soma(2, 3))
print(mensagens.ola())
