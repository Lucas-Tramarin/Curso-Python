def calculaQuadrado(numero):
    return f"O quadrado de {numero} é: {numero ** 2}"

lista_numeros = [1, 2, 3, 4, 5, 6]
calculo = map(calculaQuadrado, lista_numeros)
#calculo = list(map(calculaQuadrado, lista_numeros))

print(calculo)  # Isso imprimirá o objeto map se ele não for convertido para lista antes

for n in calculo:
    print(n)