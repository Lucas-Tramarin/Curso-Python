def verifica_numero(valor):
    # 1) Tentando converter para número:
    try:
        numero = float(valor)
    except ValueError:
        return "Erro: valor digitado não é numérico."

    # 2) Lógica principal da função:
    if numero > 0:
        return 'P'
    else:
        return 'N'


# Programa principal:
entrada = input("Digite um número: ")
resultado = verifica_numero(entrada)
print(f"Resultado: {resultado}")
