nomes = "João Paulo/Maria Paula/Ana Beatriz/José Pedro"
print(nomes.split('/'))

#O exemplo abaixo usa vírgula como separador, comum em arquivos CSV:
nomes = "João Paulo,Maria Paula,Ana Beatriz,José Pedro"
print(nomes.split(','))