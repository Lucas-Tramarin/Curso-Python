''' Faça um programa que solicite a data de nascimento (dd/mm/aaaa) do usuário e
 imprima a data com o nome do mês por extenso. 
 Exemplo: Entrada: 25/12/2000 Saída: 25 de Dezembro de 2000'''

data_nascimento = input("Digite sua data de nascimento (dd/mm/aaaa): ")
dia, mes, ano = data_nascimento.split('/') #aqui desempacotamos a lista retornada pelo split
mes_extenso = ''
if mes == '01':
    mes_extenso = 'Janeiro'
elif mes == '02':
    mes_extenso = 'Fevereiro'
elif mes == '03':
    mes_extenso = 'Março'
elif mes == '04':
    mes_extenso = 'Abril'
elif mes == '05':
    mes_extenso = 'Maio'
elif mes == '06':
    mes_extenso = 'Junho'
elif mes == '07':
    mes_extenso = 'Julho'
elif mes == '08':
    mes_extenso = 'Agosto'
elif mes == '09':
    mes_extenso = 'Setembro'        
elif mes == '10':
    mes_extenso = 'Outubro'
elif mes == '11':
    mes_extenso = 'Novembro'
elif mes == '12':
    mes_extenso = 'Dezembro'
print(f'Sua data de nascimento é: {int(dia)} de {mes_extenso} de {ano}')  #A conversão de dia para int remove o zero à esquerda que pode estar presente na entrada do usuário.

#Outra forma de fazer usando lista
data_nascimento = input("Digite sua data de nascimento (dd/mm/aaaa): ")
dia, mes, ano = data_nascimento.split('/')
meses = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro']
mes_extenso = meses[int(mes)-1] #-1 porque o índice da lista começa em 0
print(f'Sua data de nascimento é: {int(dia)} de {mes_extenso} de {ano}')

#Outra forma de fazer usando dicionário
data_nascimento = input("Digite sua data de nascimento (dd/mm/aaaa): ")
dia, mes, ano = data_nascimento.split('/')
meses = {'01': 'Janeiro', '02': 'Fevereiro', '03': 'Março', '04': 'Abril', '05': 'Maio', '06': 'Junho', '07': 'Julho', '08': 'Agosto', '09': 'Setembro', '10': 'Outubro', '11': 'Novembro', '12': 'Dezembro'}
mes_extenso = meses[mes]
print(f'Sua data de nascimento é: {int(dia)} de {mes_extenso} de {ano}')    

#Outra forma de fazer usando datetime
from datetime import datetime   
data_nascimento = input("Digite sua data de nascimento (dd/mm/aaaa): ")
data_obj = datetime.strptime(data_nascimento, '%d/%m/%Y')  #converte string para objeto datetime, usando o formato especificado
mes_extenso = data_obj.strftime('%B') #obtém o nome do mês por extenso, %B retorna o nome completo do mês, %b retorna a forma abreviada, %m retorna o número do mês com dois dígitos, %-#d retorna o dia com dois dígitos, %Y retorna o ano com quatro dígitos
print(f'Sua data de nascimento é: {data_obj.day} de {mes_extenso} de {data_obj.year}')

#Outra forma de fazer usando calendar
import calendar
data_nascimento = input("Digite sua data de nascimento (dd/mm/aaaa): ")
dia, mes, ano = data_nascimento.split('/')
mes_extenso = calendar.month_name[int(mes)] #month_name é uma lista onde o índice 1 é Janeiro, 2 é Fevereiro, etc.
print(f'Sua data de nascimento é: {int(dia)} de {mes_extenso} de {ano}')

#Outra forma de fazer usando pandas
import pandas as pd 
data_nascimento = input("Digite sua data de nascimento (dd/mm/aaaa): ")
data_obj = pd.to_datetime(data_nascimento, format='%d/%m/%Y') #converte string para objeto datetime do pandas
mes_extenso = data_obj.strftime('%B')
print(f'Sua data de nascimento é: {data_obj.day} de {mes_extenso} de {data_obj.year}')

#Outra forma de fazer usando numpy
import numpy as np
import calendar
data_nascimento = input("Digite sua data de nascimento (aaaa-mm-dd): ") #entrada no formato dd/mm/aaaa
data_obj = np.datetime64(data_nascimento, 'D') #converte string para objeto datetime do numpy, 'D' indica que é no formato de dias
print(data_obj)
mes_extenso = np.datetime_as_string(data_obj, unit='M').split('-')[1] #obtém o mês como número com dois dígitos, depois converte para nome do mês usando calendar, pois numpy não tem função para nome do mês
print(mes_extenso)
mes_extenso = calendar.month_name[int(mes_extenso)]
print(f'Sua data de nascimento é: {int(str(data_obj).split("-")[2])} de {mes_extenso} de {str(data_obj).split("-")[0]}')