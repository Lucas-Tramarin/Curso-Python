lista = [1, 2, 3, 4, 5, 6]
lista1 = list(map(lambda x: x**2, lista)) 
#eleva ao quadrado os elementos de lista para criar lista1
print("lista = ", lista,"\n\nlista1 = ", lista1)