from .pagamento import valorPagamento

__all__ = ["valorPagamento"]
