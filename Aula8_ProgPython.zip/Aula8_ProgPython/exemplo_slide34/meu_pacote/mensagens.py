def ola():
    return "Olá, eu sou um módulo do pacote!"
