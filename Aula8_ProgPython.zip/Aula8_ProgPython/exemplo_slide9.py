def nomeDaFuncao(parametro):
    print('Esta função recebeu ', parametro, ' como parâmetro. ')
    print('O tipo deste parâmetro , é: ', type(parametro))
    return '\nCurso de Python é top!'
print(nomeDaFuncao('Olá Mundo!'))