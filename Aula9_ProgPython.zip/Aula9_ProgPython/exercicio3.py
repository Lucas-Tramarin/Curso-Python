'''Escreva uma função que imprime todos os números primos entre 1 e 500
Dica: um número é primo se ele for divisível apenas por 1 e ele mesmo, use o operador % (resto da divisão) para isso.
'''
def eh_primo(num):
    if num < 2:
        return False
    for i in range(2, int(num**0.5) + 1):
        if num % i == 0:
            return False
    return True

#primos = list(filter(eh_primo, range(0, 1))) 
primos = list(filter(eh_primo, range(1, 501))) #a função filter aplica a função eh_primo a cada elemento do range de 1 a 500
print("Números primos entre 1 e 500:", primos)

#fim do programa