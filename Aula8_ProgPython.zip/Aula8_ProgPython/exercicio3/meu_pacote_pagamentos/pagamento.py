# meu_pacote_pagamentos/pagamento.py

def valorPagamento(prestacao, dias_atraso):
    """
    Calcula o valor a ser pago por uma prestação.
    - prestacao: valor da prestação (número ou string que represente número)
    - dias_atraso: número de dias em atraso (int ou string que represente int)
    Regras:
      - se dias_atraso <= 0: retorna o valor da prestação sem acréscimos
      - se dias_atraso > 0: aplica multa de 3% + juros de 0.1% ao dia
    Retorna o valor final (float, com 2 casas decimais).
    Lança ValueError se parâmetros forem inválidos.
    """
    # validação e conversão
    try:
        valor = float(prestacao)
    except (TypeError, ValueError):
        raise ValueError("Prestação deve ser um número válido.")

    try:
        dias = int(dias_atraso)
    except (TypeError, ValueError):
        raise ValueError("Dias de atraso deve ser um inteiro válido.")

    if dias <= 0:
        return round(valor, 2)

    multa = 0.03 * valor              # 3%
    juros = 0.001 * valor * dias      # 0.1% ao dia = 0.001 * valor * dias
    total = valor + multa + juros
    return round(total, 2)
