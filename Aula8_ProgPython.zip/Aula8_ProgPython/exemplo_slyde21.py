def retangulo(largura, altura, caractere="*"):
    linha = caractere * largura
    for i in range(altura):
        print(linha)
retangulo(caractere="$", altura=5, largura=15) # Chama a função com argumentos nomeados
print()  # Linha em branco para separar as saídas
retangulo(10, 4)  # Chama a função com argumentos posicionais
