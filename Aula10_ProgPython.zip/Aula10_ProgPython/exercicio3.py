'''Faça um programa que leia um número de telefone, e corrija o número no caso deste conter somente 8 dígitos, 
acrescentando o ‘9' na frente. O usuário pode informar o número com ou sem o traço separador.'''

telefone = input("Digite o número de telefone (com ou sem traço): ")
telefone = telefone.replace('-', '')  # Remove o traço, se houver
if len(telefone) == 8:
    telefone = '9' + telefone
print(f"Telefone corrigido: {telefone}")
