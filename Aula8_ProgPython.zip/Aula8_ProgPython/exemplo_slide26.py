def validar_faixa(numero, inicio, fim):
    if numero.isdigit():
        if int(numero) < int(inicio) or int(numero) > int(fim):
            print(f"Número inválido! Informe um número inteiro entre {inicio} e {fim}.")
        else:
            return True
    else:
        print(f"Valor inválido! Informe um número inteiro entre {inicio} e {fim}.")

#Chamando a função em loop até o usuário informar um valor válido:        
while True:
    resposta = input("Informe um número inteiro entre 1 e 10: ")
    if validar_faixa(resposta, 1, 10):
        print(f"Você informou o número {resposta}, que está dentro da faixa permitida.")
        break		

print("Aqui o programa continua... Após o usuário informar um valor válido.")