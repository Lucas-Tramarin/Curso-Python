nomes = "João Paulo\nMaria Paula\nAna Beatriz\nJosé Pedro"

print(nomes.splitlines())