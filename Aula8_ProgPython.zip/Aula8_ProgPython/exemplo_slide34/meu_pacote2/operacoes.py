def soma(a, b):
    return a + b
