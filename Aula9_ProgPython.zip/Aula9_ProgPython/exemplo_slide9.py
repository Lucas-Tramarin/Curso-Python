lista = [1, 2, 3, 4, 5, 6]
lista1 = list(filter(lambda x: x % 2 != 0, lista)) 
#lista1 = filter(lambda x: x % 2 != 0, lista) #sem converter para lista imprime o objeto filter

#retorna a lista de números ímpares
print("lista = ", lista,"\n\nlista1 = ", lista1)